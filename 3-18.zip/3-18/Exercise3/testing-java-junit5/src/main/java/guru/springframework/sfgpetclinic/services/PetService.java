package guru.springframework.sfgpetclinic.services;

import guru.springframework.sfgpetclinic.model.Pet;

/**
 * Created by jt on 7/18/18.
 */
public interface PetService extends CrudService<Pet, Long> {

}
