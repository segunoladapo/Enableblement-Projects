package guru.springframework.sfgpetclinic.fauxspring;


public class ModelAndView {

    public ModelAndView() {
    }

    public ModelAndView(String view) {
    }

    public void addObject(Object o){}

}
