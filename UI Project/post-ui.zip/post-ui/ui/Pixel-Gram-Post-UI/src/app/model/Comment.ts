export class Comment {
  user: string;
  content: string;
  createdTime: string;
}
