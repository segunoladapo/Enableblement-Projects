export const environment = {
  production: true,
  postEndpoint: 'http://localhost:8081/post',
  commentEndpoint: 'http://localhost:8081/post/{0}/comment?pageSize=5&currentPage={1}'
};
