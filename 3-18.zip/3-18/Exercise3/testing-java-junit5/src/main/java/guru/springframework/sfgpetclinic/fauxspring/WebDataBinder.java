package guru.springframework.sfgpetclinic.fauxspring;

public interface WebDataBinder {
    void setDisallowedFields(String id);
}
