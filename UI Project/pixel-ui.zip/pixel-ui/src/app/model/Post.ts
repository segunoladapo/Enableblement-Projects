export class Post {
  user: string;
  imageUrl: string;
  likeCount: number;
  createdTime: string;
  id: number;
  commentCount: number;
  description: string;
}
