package guru.springframework.sfgpetclinic.repositories;


public interface Repository<T, ID> {

}