export const environment = {
  production: true,
  postEndpoint: 'http://localhost:8181/post',
  commentEndpoint: 'http://localhost:8181/post/{0}/comment?pageSize=5&currentPage={1}'
};
